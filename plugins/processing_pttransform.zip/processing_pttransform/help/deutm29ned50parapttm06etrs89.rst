De ED50 para PT-TM06/ETRS89
================================

Descri��o
-----------

Esta ferramenta usa como ficheiro de entrada um vector no "ED50 / Zona UTM 29N" (EPSG:23029). O ficheiro de sa�da ser� um shapefile no Sistema de Refer�ncia PT-TM06/ETRS89 (EPSG:3763).


Par�metros
----------

- ``Ficheiro de entrada [Vector]``: vector de entrada


Ficheiros de sa�da
-------

- ``Ficheiro de sa�da [Vector]``: vector de sa�da em formato shapefile
