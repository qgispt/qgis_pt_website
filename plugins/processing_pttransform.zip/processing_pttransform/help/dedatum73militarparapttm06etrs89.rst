De Datum 73 Militar para PT-TM06/ETRS89
================================

Descri��o
-----------

Esta ferramenta usa como ficheiro de entrada um vector no "Datum 73 Militar" (ESRI:102160). O ficheiro de sa�da ser� um shapefile no Sistema de Refer�ncia PT-TM06/ETRS89 (EPSG:3763).


Par�metros
----------

- ``Ficheiro de entrada [Vector]``: vector de entrada

- ``Grelhas NTv2 [de transforma��o de Datum] a usar (Fonte)``: Escolher uma das duas grelhas NTv2 suportadas - as desenvolvidas pelo Prof. Jos� Alberto Gon�alves, da Faculdade de Ci�ncias da Universidade do Porto (FCUP), ou as produzidas pela Dire��o-Geral do Territ�rio (DGT).


Ficheiros de sa�da
-------

- ``Ficheiro de sa�da [Vector]``: vector de sa�da em formato shapefile
