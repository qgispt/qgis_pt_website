De ED50 para PT-TM06/ETRS89
================================

Descri��o
-----------

Esta ferramenta usa como ficheiro de entrada um raster no "ED50 / Zona UTM 29N" (EPSG:23029). O ficheiro de sa�da ser� um GeoTIFF no Sistema de Refer�ncia PT-TM06/ETRS89 (EPSG:3763).


Par�metros
----------

- ``Ficheiro de entrada [Raster]``: raster de entrada


Ficheiros de sa�da
-------

- ``Ficheiro de sa�da [Raster]``: raster de sa�da em formato GeoTIFF
