De Datum Lisboa para PT-TM06/ETRS89
================================

Descri��o
-----------

Esta ferramenta usa como ficheiro de entrada um raster no "Datum Lisboa" (ESRI:102165 / EPSG:20791 / EPSG:5018). O ficheiro de sa�da ser� um GeoTIFF no Sistema de Refer�ncia PT-TM06/ETRS89 (EPSG:3763).


Par�metros
----------

- ``Ficheiro de entrada [Raster]``: raster de entrada

- ``Grelhas NTv2 [de transforma��o de Datum] a usar (Fonte)``: Escolher uma das duas grelhas NTv2 suportadas - as desenvolvidas pelo Prof. Jos� Alberto Gon�alves, da Faculdade de Ci�ncias da Universidade do Porto (FCUP), ou as produzidas pela Dire��o-Geral do Territ�rio (DGT).


Ficheiros de sa�da
-------

- ``Ficheiro de sa�da [Raster]``: raster de sa�da em formato GeoTIFF
